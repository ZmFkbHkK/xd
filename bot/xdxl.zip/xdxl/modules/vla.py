from xdxl import *

@bot.on(events.CallbackQuery(data=b'cek-vless'))
async def cek_vless(event):
	async def cek_vless_(event):
		cmd = 'cek-login vless bot'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

```{z}``
**Shows Logged In Users Vless**
**» 🤖 @xdtunnell**
""",buttons=[[Button.inline("‹ Main Menu ›","vless")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_vless_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-vless'))
async def delete_vless(event):
	async def delete_vless_(event):
		cmd2 = 'vla member bot'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | sbot delete vless'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""**Successfully Deleted**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
@bot.on(events.CallbackQuery(data=b'cfg-vless'))
async def config_vless(event):
	async def config_vless_(event):

		cmd2 = 'vla member bot'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing....`")
		time.sleep(2)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{user}" | sbot cfvl'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			#today = DT.date.today()
			#later = today + DT.timedelta(days=int(exp))
			x = [x.group() for x in re.finditer("vless://(.*)",a)]
			print(x)
			info = [x.group() for x in re.finditer("info://(.*)",a)]
			print(info)
			#user = re.search("#(.*)",x[0]).group(1)
			iplim = re.search("@(.*?):",info[0])
			quota = re.search("#(.*?):",info[0])
			exp = re.search("&(.*?):",info[0])
			#exp = re.search("info://(.*?)@",info[0])
			# domain = re.search("@(.*?):",x[0]).group(1)
			uuid = re.search("vless://(.*?)@",x[0]).group(1)
			# path = re.search("path=(.*)&",x[0]).group(1)
			msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
   **⟨ Config Xray/Vless Account ⟩**
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Username :** `{user}`
**» Host/Ip :** `{DOMAIN}`
**» Limit IP :** `{iplim} Device`
**» Limit Quota :** `{quota} GB`
**» Port TLS :** `443`
**» Port NTLS :** `80`
**» Port GRPC :** `443`
**» id :** `{uuid}`
**» Security :** `none`
**» NetWork :** `ws - grpc`
**» Path :** `/vless`
**» ServiceName  :** `vless`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link TLS  :** 
```{x[0]}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link NTLS  :**
```{x[1].replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link GRPC  :**
```{x[2].replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Format OpenClash :**
`https://{DOMAIN}:81/vless-{user}.txt`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Expired On:** `{exp}`
**» 🤖 @xdtunnell**
**━━━━━━━━━━━━━━━━━━━━━━━**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await config_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'mvl'))
async def member_vless(event):
	async def member_vless_(event):
		cmd = 'vla member bot'.strip()
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Wait.. Setting up Server Data`")
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
```{z}```
**List Member Xray/Vless Account**
🤖 **» @xdtunnell**
""",buttons=[[Button.inline("‹ Main Menu ›","vless")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await member_vless_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'renew-vless'))
async def vless_renew(event):
	async def vless_renew_(event):
		cmd2 = 'vla member bot'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond('**Perpanjang (Days):**')
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		cmd = f'printf "%s\n" "{user}" "{exp}" | sbot renew vless'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("""
			**Username** `{user}` **Tidak Ada !**
			""")
		else:
			msg = f"""
**━━━━━━━━━━━━━━━━━━━** 
 **⟨ Success Renew Vless ⟩**
**━━━━━━━━━━━━━━━━━━━**
**Username:** `{user}`
**Diperpanjang:** `{exp} Hari`
**━━━━━━━━━━━━━━━━━━━**
🤖 **» @xdtunnell**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vless_renew_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'lvl'))
async def lock_vless(event):
	async def lock_vless_(event):
		cmd2 = 'vla member bot'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | sbot lock vless'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""**Successfully Locked User:** `{user}`"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await lock_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
@bot.on(events.CallbackQuery(data=b'uvl'))
async def unlock_vless(event):
	async def unlock_vless_(event):
		cmd2 = 'vla member bot'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | sbot unlock vmess'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""**Successfully Unlocked User:** `{user}`"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await unlock_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'vl-ip'))
async def ip_vless(event):
	async def ip_vless_(event):
		cmd2 = 'vla member bot'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as iplim:
			await event.respond('**Limit User (IP):**')
			iplim = iplim.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			iplim = (await iplim).raw_text
		cmd = f'printf "%s\n" "{user}" "{iplim}" | sbot ipvl'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━** 
 **⟨ Success Change Limit IP Vless ⟩**
**━━━━━━━━━━━━━━━━━━━━━━━**
**Username:** `{user}`
**Limit IP:** `{iplim} Device`
**━━━━━━━━━━━━━━━━━━━━━━━**
🤖 **» @xdtunnell**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ip_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'vl-quota'))
async def quota_vless(event):
	async def quota_vless_(event):
		cmd2 = 'vla member bot'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as quota:
			await event.respond('**Limit Quota (GB):**')
			quota = quota.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			quota = (await quota).raw_text
		cmd = f'printf "%s\n" "{user}" "{quota}" | sbot qvl'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━** 
 **⟨ Success Change Limit Quota Vless ⟩**
**━━━━━━━━━━━━━━━━━━━━━━━**
**Username:** `{user}`
**Limit Quota:** `{quota} GB`
**━━━━━━━━━━━━━━━━━━━━━━━**
🤖 **» @xdtunnell**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await quota_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'vless'))
async def vless(event):
	async def vless_(event):
		inline = [
[Button.inline(" Create Vless ","create-vless"),
Button.inline(" Triall Vless ","trial-vless")], 
[Button.inline(" Delete Vless ","delete-vless"), 
Button.inline(" Renew Vless ","renew-vless")], 
[Button.inline(" Check User Login ","cek-vless"),
Button.inline(" Check Config ","cfg-vless")],
[Button.inline(" Change Limit IP ","vl-ip"), 
Button.inline(" Change Limit Quota ","vl-quota")], 
[Button.inline(" Locked Vless ","lvl"), 
Button.inline(" Unlocked Vless ","uvl")], 
[Button.inline(" List Member ","memvl"), 
Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
        **⟨ XRAY/VLESS ⟩**
━━━━━━━━━━━━━━━━━━━━━━━ 
🔰 **» Service:** `VLESS`
🔰 **» Hostname/IP:** `{DOMAIN}`
🔰 **» ISP:** `{z["isp"]}`
🔰 **» Country:** `{z["country"]}`
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vless_(event)
	else:
		await event.answer("Access Denied",alert=True)
