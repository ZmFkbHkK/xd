from xdxl import *

#DELETESSH
@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
	async def delete_ssh_(event):
		cmd2 = 'sbot member ssh'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
			cmd = f'printf "%s\n" "{user}" | sbot delete ssh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{user}` **Not Found**")
		else:
			await event.respond(f"**Successfully Deleted** `{user}`")
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

# // LOCKED USER SSH
@bot.on(events.CallbackQuery(data=b'lssh'))
async def locked_ssh(event):
	async def locked_ssh_(event):
		cmd2 = 'sbot member ssh'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
			cmd = f'printf "%s\n" egrep "{user}" /etc/passwd && passwd -l "{user}" && systemctl restart ws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{user}` **Not Found**")
		else:
			await event.respond(f"**Successfully Locked** `{user}`")
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await locked_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
# // UNLOCKED USER SSH
@bot.on(events.CallbackQuery(data=b'ussh'))
async def unlocked_ssh(event):
	async def unlocked_ssh_(event):
		cmd2 = 'sbot member ssh'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
			cmd = f'printf "%s\n" egrep "{user}" /etc/passwd && passwd -u "{user}" && systemctl restart ws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{user}` **Not Found**")
		else:
			await event.respond(f"**Successfully Unlocked** `{user}`")
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await unlocked_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
	async def create_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**Password:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as iplim:
			await event.respond("**Limit IP:**")
			iplim = iplim.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			iplim = (await iplim).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline(" 3 Day ","3"),
Button.inline(" 7 Day ","7")],
[Button.inline(" 30 Day ","30"),
Button.inline(" 60 Day ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		cmd = f'printf "%s\n" "{user}" "{pw}" "{iplim}" "{exp}" | adsh all'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			info = [x.group() for x in re.finditer("info://(.*)",a)]
			print(info)
			iplimit = re.search("@(.*?):",info[0])
			msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
   **⟨ Add SSH/OpenVPN Account ⟩**
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Username :** `{user.strip()}`
**» Password :** `{pw.strip()}`
**» Limit IP :** `{iplimit} Device`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Host/Ip :** `{DOMAIN}`
**» Host Slowdns :** `{HOST}`
**» Pub Key :** `{PUB}`
**» Port OpenSSH :** `2222, 22`
**» Port UDP Custom :** `54-65535`
**» Port DNS :** `53`
**» Port Dropbear :** `143, 109`
**» Port SSH WS :** `80`
**» Port SSH SSL WS  :** `443`
**» Port OVPN WS TCP :** `2095`
**» Port OVPN SSL :** `442`
**» Port OVPN TCP :** `1194`
**» Port OVPN UDP :** `2200`
**» Proxy Squid :** `3128`
**» BadVPN/Udgpw Ssh:** `7100 - 7300`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Payload:** 
`GET http://bug.com/ HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» OpenVPN Download:** 
`https://{DOMAIN}:81`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Save Link Account:** 
`https://{DOMAIN}:81/ssh-{user.strip()}.txt`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Expired:** `{later}`
**» Channel:** t.me/nauracloud/30
**━━━━━━━━━━━━━━━━━━━━━━━**

"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
	async def show_ssh_(event):
		cmd = 'sbot member ssh'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
```
{z}
```
**Show All SSH/OpenVPN User**

""",buttons=[[Button.inline("‹ Main Menu ›","ssh")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await show_ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
	async def trial_ssh_(event):
		async with bot.conversation(chat) as iplim:
			await event.respond("**Limit IP:**")
			iplim = iplim.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			iplim = (await iplim).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Minutes**",buttons=[
[Button.inline(" 10 Menit ","10")],
[Button.inline(" 15 Menit ","15"),
Button.inline(" 30 Menit ","30")],
[Button.inline(" 60 Menit ","60"),
Button.inline(" 120 Menit ","120")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		user = "trial-"+str(random.randint(100,1000))
		pw = "1"
		cmd = f'printf "%s\n" "{user}" "{pw}" "{iplim}" "{exp}" | adsh abot'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**User Already Exist**")
		else:
			#later = today + DT.timedelta(days=int(exp))
			info = [x.group() for x in re.finditer("info://(.*)",a)]
			print(info)
			iplimit = re.search("@(.*?):",info[0])
			msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
   **⟨ Triall SSH/OpenVPN Account ⟩**
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Username :** `{user}`
**» Password :** `{pw}`
**» Limit IP :** `{iplimit} Device`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Host/Ip :** `{DOMAIN}`
**» Host Slowdns :** `{HOST}`
**» Pub Key :** `{PUB}`
**» Port OpenSSH :** `2222, 22`
**» Port UDP Custom :** `54-65535`
**» Port DNS :** `53`
**» Port Dropbear :** `143, 109`
**» Port SSH WS :** `80`
**» Port SSH SSL WS  :** `443`
**» Port OVPN WS TCP :** `2095`
**» Port OVPN SSL :** `442`
**» Port OVPN TCP :** `1194`
**» Port OVPN UDP :** `2200`
**» Proxy Squid :** `3128`
**» BadVPN/Udgpw Ssh:** `7100 - 7300`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Payload:** 
`GET http://bug.com/ HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» OpenVPN Download:** 
`https://{DOMAIN}:81`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Save Link Account:** 
`https://{DOMAIN}:81/ssh-{user.strip()}.txt`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Expired:** `{exp} minutes`
**» Channel:** t.me/nauracloud/30
**━━━━━━━━━━━━━━━━━━━━━━━**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)


@bot.on(events.CallbackQuery(data=b'cfg-ssh'))
async def config_ssh(event):
	async def config_ssh_(event):
		cmd2 = 'sbot member ssh'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing....`")
		time.sleep(2)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{user}" | sbot cfssh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			#today = DT.date.today()
			#later = today + DT.timedelta(days=int(exp))
			info = [x.group() for x in re.finditer("info://(.*)",a)]
			print(info)
			#user = re.search("#(.*)",x[0]).group(1)
			iplim = re.search("@(.*?):",info[0])
			exp = re.search("&(.*?):",info[0])
			pw = re.search("#(.*?):",info[0])
			msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
   **⟨ Config SSH/OpenVPN Account ⟩**
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Username :** `{user}`
**» Password :** `{pw}`
**» Limit IP :** `{iplim} Device`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Host/Ip :** `{DOMAIN}`
**» Host Slowdns :** `{HOST}`
**» Pub Key :** `{PUB}`
**» Port OpenSSH :** `2222, 22`
**» Port UDP Custom :** `54-65535`
**» Port DNS :** `53`
**» Port Dropbear :** `143, 109`
**» Port SSH WS :** `80`
**» Port SSH SSL WS  :** `443`
**» Port OVPN WS SSL :** `2095`
**» Port OVPN SSL :** `442`
**» Port OVPN TCP :** `1194`
**» Port OVPN UDP :** `2200`
**» Proxy Squid :** `3128`
**» BadVPN/Udgpw Ssh:** `7100 - 7300`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Payload:** 
`GET http://bug.com/ HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» OpenVPN Download:** 
`https://{DOMAIN}:81`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Save Link Account:** 
`https://{DOMAIN}:81/ssh-{user.strip()}.txt`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Expired:** `{exp} minutes`
**» Channel:** t.me/nauracloud/30
**━━━━━━━━━━━━━━━━━━━━━━━**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await config_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

		
@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
	async def login_ssh_(event):
		cmd = 'cek-login ssh bot'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

```{z}```

**Check User Login SSH/OpenVPN Account**
""",buttons=[[Button.inline("‹ Main Menu ›","ssh")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await login_ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'ssh-ip'))
async def ssh_ip(event):
	async def ssh_ip_(event):
		cmd2 = 'sbot member ssh'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as iplim:
			await event.respond('**Limit User (IP):**')
			iplim = iplim.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			iplim = (await iplim).raw_text
		cmd = f'printf "%s\n" "{user}" "{iplim}" | sbot ipssh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("""
			**Username** `{user}` **Tidak Ada !**
			""")
		else:
			msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━** 
 **⟨ Success Change Limit IP SSH ⟩**
**━━━━━━━━━━━━━━━━━━━━━━━**
**Username:** `{user}`
**Limit IP:** `{iplim} Device`
**━━━━━━━━━━━━━━━━━━━━━━━**
🤖 **» t.me/nauracloud/30**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ssh_ip_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'renew-ssh'))
async def ssh_renew(event):
	async def ssh_renew_(event):
		cmd2 = 'sbot member ssh'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond('**Perpanjang (Days):**')
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		cmd = f'printf "%s\n" "{user}" "{exp}" | sbot renew ssh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("""
			**Username** `{user}` **Tidak Ada !**
			""")
		else:
			msg = f"""
**━━━━━━━━━━━━━━━━━━━** 
 **⟨ Success Renew SSH ⟩**
**━━━━━━━━━━━━━━━━━━━**
**Username:** `{user}`
**Diperpanjang:** `{exp} Hari`
**━━━━━━━━━━━━━━━━━━━**
🤖 **» t.me/nauracloud/30**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ssh_renew_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
	async def ssh_(event):
		inline = [
[Button.inline(" Create SSH ","create-ssh"),
Button.inline(" Triall SSH ","trial-ssh")], 
[Button.inline(" Delete SSH ","delete-ssh"), 
Button.inline(" Renew SSH ","renew-ssh")], 
[Button.inline(" Check User Login ","login-ssh"),
Button.inline(" Check Config ","cfg-ssh")],
[Button.inline(" Change Limit IP ","ssh-ip"), 
Button.inline(" Locked SSH ","lssh")], 
[Button.inline(" Unlocked SSH ","ussh"), 
Button.inline(" List Member ","memssh")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
        **⟨ SSH/OpenVPN ⟩**
━━━━━━━━━━━━━━━━━━━━━━━ 
🔰 **» Service:** `SSH/OpenVPN`
🔰 **» Domain:** `{DOMAIN}`
🔰 **» ISP:** `{z["isp"]}`
🔰 **» Country:** `{z["country"]}`
🤖 **» t.me/nauracloud/30**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)
