from xdxl import *

@bot.on(events.CallbackQuery(data=b'cek-trojan'))
async def cek_trojan(event):
	async def cek_trojan_(event):
		cmd = 'cek-login trojan bot'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

```{z}```

**Shows Logged In Users Trojan**
**» 🧊t.me/nauracloud/30**
""",buttons=[[Button.inline("‹ Main Menu ›","trojan")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_trojan_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'cfg-trojan'))
async def config_trojan(event):
	async def config_trojan_(event):
		cmd2 = 'tra member bot'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing....`")
		time.sleep(2)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{user}" | sbot cftr'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			#today = DT.date.today()
			#later = today + DT.timedelta(days=int(exp))
			x = [x.group() for x in re.finditer("trojan://(.*)",a)]
			print(x)
			info = [x.group() for x in re.finditer("info://(.*)",a)]
			print(info)
			#user = re.search("#(.*)",x[0]).group(1)
			iplim = re.search("@(.*?):",info[0])
			quota = re.search("#(.*?):",info[0])
			exp = re.search("&(.*?):",info[0])
			#exp = re.search("info://(.*?)@",info[0])
			# domain = re.search("@(.*?):",x[0]).group(1)
			uuid = re.search("trojan://(.*?)@",x[0]).group(1)
			# path = re.search("path=(.*)&",x[0]).group(1)
			msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
   **⟨ Config Xray/Trojan Account ⟩**
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Username :** `{user}`
**» Host/Ip :** `{domain}`
**» Limit IP :** `{iplim} Device`
**» Limit Quota :** `{quota} GB`
**» Port NTLS :** `80`
**» Port TLS :** `443`
**» Port gRPC :** `443`
**» Key :** `{uuid}`
**» NetWork :** `ws - grpc`
**» Path :** `/trojan`
**» ServiceName  :** `trojan`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link TLS  :** 
```{x[0]}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link NTLS  :**
```{x[1].replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Link GRPC  :**
```{x[2].replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Format OpenClash :**
`https://{DOMAIN}:81/trojan-{user}.txt`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Expired On:** `{exp}`
**» 🤖 t.me/nauracloud/30**
**━━━━━━━━━━━━━━━━━━━━━━━**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await config_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-trojan'))
async def delete_trojan(event):
	async def delete_trojan_(event):
		cmd2 = 'tra member bot'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | sbot delete trojan'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""**Successfully Deleted**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'memtr'))
async def member_trojan(event):
	async def member_trojan_(event):
		cmd = 'tra member bot'.strip()
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Wait.. Setting up Server Data`")
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
```{z}```
**List Member Xray/Trojan Account**
🤖 **» t.me/nauracloud/30**
""",buttons=[[Button.inline("‹ Main Menu ›","trojan")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await member_trojan_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'renew-trojan'))
async def trojan_renew(event):
	async def trojan_renew_(event):
		cmd2 = 'tra member bot'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond('**Perpanjang (Days):**')
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		cmd = f'printf "%s\n" "{user}" "{exp}" | sbot renew trojan'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("""
			**Username** `{user}` **Tidak Ada !**
			""")
		else:
			msg = f"""
**━━━━━━━━━━━━━━━━━━━** 
 **⟨ Success Renew Trojan ⟩**
**━━━━━━━━━━━━━━━━━━━**
**Username:** `{user}`
**Diperpanjang:** `{exp} Hari`
**━━━━━━━━━━━━━━━━━━━**
🤖 **» t.me/nauracloud/30**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trojan_renew_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'ltr'))
async def lock_trojan(event):
	async def lock_trojan_(event):
		cmd2 = 'tra member bot'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | sbot lock trojan'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""**Successfully Locked User:** `{user}`"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await lock_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
@bot.on(events.CallbackQuery(data=b'utr'))
async def unlock_trojan(event):
	async def unlock_trojan_(event):
		cmd2 = 'tra member bot'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | sbot unlock trojan'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""**Successfully Unlocked User:** `{user}`"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await unlock_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'tr-ip'))
async def ip_trojan(event):
	async def ip_trojan_(event):
		cmd2 = 'tra member bot'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as iplim:
			await event.respond('**Limit User (IP):**')
			iplim = iplim.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			iplim = (await iplim).raw_text
		cmd = f'printf "%s\n" "{user}" "{iplim}" | sbot iptr'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━** 
 **⟨ Success Change Limit IP Trojan ⟩**
**━━━━━━━━━━━━━━━━━━━━━━━**
**Username:** `{user}`
**Limit IP:** `{iplim} Device`
**━━━━━━━━━━━━━━━━━━━━━━━**
🤖 **» t.me/nauracloud/30**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ip_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'tr-quota'))
async def quota_trojan(event):
	async def quota_trojan_(event):
		cmd2 = 'tra member bot'.strip()
		x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd2, shell=True).decode("utf-8")
		async with bot.conversation(chat) as user:
			await event.respond(f"""
			```{z}```
			**Input Username:**""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as quota:
			await event.respond('**Limit Quota (GB):**')
			quota = quota.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			quota = (await quota).raw_text
		cmd = f'printf "%s\n" "{user}" "{quota}" | sbot qtr'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━** 
 **⟨ Success Change Limit Quota Trojan ⟩**
**━━━━━━━━━━━━━━━━━━━━━━━**
**Username:** `{user}`
**Limit Quota:** `{quota} GB`
**━━━━━━━━━━━━━━━━━━━━━━━**
🤖 **» t.me/nauracloud/30**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await quota_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan(event):
	async def trojan_(event):
		inline = [
[Button.inline(" Create Trojan ","create-trojan"),
Button.inline(" Triall Trojan ","trial-trojan")], 
[Button.inline(" Delete Trojan ","delete-trojan"), 
Button.inline(" Renew Trojan ","renew-trojan")], 
[Button.inline(" Check User Login ","cek-trojan"),
Button.inline(" Check Config ","cfg-trojan")],
[Button.inline(" Change Limit IP ","tr-ip"), 
Button.inline(" Change Limit Quota ","tr-quota")], 
[Button.inline(" Locked Trojan ","ltr"), 
Button.inline(" Unlocked Trojan ","utr")], 
[Button.inline(" List Member ","memtr"), 
Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
        **⟨ XRAY/TROJAN ⟩**
━━━━━━━━━━━━━━━━━━━━━━━ 
🔰 **» Service:** `TROJAN`
🔰 **» Hostname/IP:** `{DOMAIN}`
🔰 **» ISP:** `{z["isp"]}`
🔰 **» Country:** `{z["country"]}`
🔰 **» t.me/nauracloud/30**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trojan_(event)
	else:
		await event.answer("Access Denied",alert=True)